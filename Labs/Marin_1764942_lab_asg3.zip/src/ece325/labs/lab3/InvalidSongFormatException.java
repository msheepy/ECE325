package ece325.labs.lab3;

public class InvalidSongFormatException extends Exception {
	public InvalidSongFormatException(String message) {
		super(message);
	}
}
