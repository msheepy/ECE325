package ece325.labs.lab3;
import java.util.ArrayList;

public class test {
    public void add(String e){
    }
    public static void main(String[] args) {
        ArrayList<String> a = new ArrayList<String>();
        a.add("A");
        a.add("B")
    }
}
