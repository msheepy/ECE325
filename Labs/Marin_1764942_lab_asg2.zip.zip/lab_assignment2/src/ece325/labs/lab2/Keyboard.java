package ece325.labs.lab2;

public class Keyboard extends Instrument{
	public Keyboard() {}
    @Override
    public String toString(){
        return "Keyboard";
    }
}
