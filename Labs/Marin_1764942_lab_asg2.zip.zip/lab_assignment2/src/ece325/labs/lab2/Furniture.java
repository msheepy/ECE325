package ece325.labs.lab2;

abstract class Furniture extends Equipment{}
