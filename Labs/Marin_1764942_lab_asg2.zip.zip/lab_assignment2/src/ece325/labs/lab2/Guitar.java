package ece325.labs.lab2;

public class Guitar extends Instrument{
	public Guitar() {}
    @Override
    public String toString(){
        return "Guitar";
    }
}
