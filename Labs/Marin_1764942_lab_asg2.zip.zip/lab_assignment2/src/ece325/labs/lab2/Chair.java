package ece325.labs.lab2;

public class Chair extends Furniture{
	public Chair() {}
    @Override
    public String toString(){
        return "Chair";
    }
}
