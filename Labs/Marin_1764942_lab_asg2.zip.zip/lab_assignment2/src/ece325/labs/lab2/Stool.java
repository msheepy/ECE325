package ece325.labs.lab2;

public class Stool extends Furniture{
	public Stool() {}
    @Override
    public String toString(){
        return "Stool";
    }
}
