package ece325.labs.lab2;

abstract class Instrument extends Equipment{}
