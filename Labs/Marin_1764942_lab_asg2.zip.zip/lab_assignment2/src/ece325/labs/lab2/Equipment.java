package ece325.labs.lab2;

abstract class Equipment {}
